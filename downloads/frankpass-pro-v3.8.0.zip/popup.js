/**
 * FrankPass Pro - Multi-User Profile System
 * Features: Profile Management, 4-Digit PIN Lock, Security Questions Recovery
 * Tier System: Silver (1), Gold (5), Platinum (10), Diamond (Unlimited)
 */

// ==================== CONSTANTS ====================
const SECURITY_QUESTIONS = [
    { id: 1,  text: "What is the name of your childhood best friend?" },
    { id: 2,  text: "What was the name of your first pet?" },
    { id: 3,  text: "What city were you born in?" },
    { id: 4,  text: "What was the name of your first school?" },
    { id: 5,  text: "What is your mother's maiden name?" },
    { id: 6,  text: "What was your first phone brand?" },
    { id: 7,  text: "What is the name of the street you grew up on?" },
    { id: 8,  text: "What was your favorite subject in school?" },
    { id: 9,  text: "What is the name of your favorite teacher?" },
    { id: 10, text: "What was the first movie you watched in a theater?" },
    { id: 11, text: "What is your favorite childhood game?" },
    { id: 12, text: "What is the name of the hospital you were born in?" },
    { id: 13, text: "What was the color of your first bicycle?" },
    { id: 14, text: "What is your favorite festival or holiday?" },
    { id: 15, text: "What was the name of your first company or workplace?" },
    { id: 16, text: "What subject did you absolutely dislike in school?" },
    { id: 17, text: "What is the name of your favorite book or movie character?" },
    { id: 18, text: "Who was your childhood hero or role model?" },
    { id: 19, text: "Custom Secret Word 1 (Enter any word only you know)" },
    { id: 20, text: "Custom Secret Word 2 (Enter any word only you know)" }
];

const TIER_LIMITS = {
    silver:   1,
    gold:     5,
    platinum: 10,
    diamond:  Infinity
};

const TIER_LABELS = {
    silver:   'SILVER',
    gold:     'GOLD',
    platinum: 'PLATINUM',
    diamond:  'DIAMOND'
};

// ==================== CRYPTO HELPERS ====================

/** SHA-256 hash a string, returning hex */
async function sha256(str) {
    const data = new TextEncoder().encode(str);
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Normalize answer: lowercase, collapse whitespace, trim */
function normalizeAnswer(ans) {
    return ans.toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Derive AES-GCM key from PIN string using PBKDF2 */
async function deriveKeyFromPin(pin, salt) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey(
        { name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
    );
}

/** Encrypt plaintext with AES-GCM using derived key */
async function encryptSecret(plaintext, pin, salt) {
    const key = await deriveKeyFromPin(pin, salt);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const enc = new TextEncoder();
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(plaintext));
    return {
        iv: Array.from(iv),
        data: Array.from(new Uint8Array(ciphertext))
    };
}

/** Decrypt ciphertext with AES-GCM using derived key */
async function decryptSecret(encrypted, pin, salt) {
    const key = await deriveKeyFromPin(pin, salt);
    const iv = new Uint8Array(encrypted.iv);
    const data = new Uint8Array(encrypted.data);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
    return new TextDecoder().decode(decrypted);
}

/** Generate a UUID v4 */
function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

// ==================== STORAGE HELPERS ====================

function getData(keys) {
    return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function setData(obj) {
    return new Promise(resolve => chrome.storage.local.set(obj, resolve));
}

// ==================== MAIN APP ====================
document.addEventListener('DOMContentLoaded', async () => {

    // --- Screen Elements ---
    const screenActivation = document.getElementById('screen-activation');
    const screenProfiles  = document.getElementById('screen-profiles');
    const screenPin       = document.getElementById('screen-pin');
    const screenRecovery  = document.getElementById('screen-recovery');
    const screenSetup     = document.getElementById('screen-setup');
    const screenGenerator = document.getElementById('screen-generator');
    const screenNewPin    = document.getElementById('screen-new-pin');
    const allScreens = [screenActivation, screenProfiles, screenPin, screenRecovery, screenSetup, screenGenerator, screenNewPin];

    function showScreen(screen) {
        allScreens.forEach(s => s.classList.add('hidden'));
        screen.classList.remove('hidden');
    }

    // --- State ---
    let profiles = [];
    let license = { key: '', tier: 'none', maxProfiles: 0 };
    let activeProfileId = null;
    let pinContext = null; // 'delete_profile' or 'view_secret'
    let pinBuffer = '';
    let pinAttempts = 0;
    let pinLockoutUntil = 0;
    let setupSelectedColor = '#6c5ce7'; // Default theme color

    // --- Color Picker Interaction ---
    document.querySelectorAll('.color-swatch').forEach(swatch => {
        swatch.addEventListener('click', () => {
            document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
            swatch.classList.add('active');
            setupSelectedColor = swatch.dataset.color;
        });
    });

    // ==================== OFFLINE DEVICE LOCK & URL RESOLUTION CONSTANTS ====================
    const MASTER_OFFLINE_SALT = 'FrankPassOfflineDeviceLockSalt2026!';
    let currentPlatformCache = [];

    /** Generate or retrieve persistent Hardware/Browser Profile Device ID */
    async function getOrCreateDeviceId() {
        const data = await getData(['fp_device_id']);
        if (data.fp_device_id && data.fp_device_id.startsWith('FP-')) {
            return data.fp_device_id;
        }
        const entropy = [
            navigator.userAgent,
            navigator.hardwareConcurrency || 4,
            navigator.language || 'en',
            screen.width + 'x' + screen.height,
            screen.colorDepth || 24,
            uuid()
        ].join('###');

        const hash = await sha256(entropy);
        const h = hash.toUpperCase();
        const deviceId = `FP-${h.substring(0, 4)}-${h.substring(4, 8)}-${h.substring(8, 12)}`;
        await setData({ fp_device_id: deviceId });
        return deviceId;
    }

    /**
     * Resolves active tab URL into an official database platform or normalized fallback
     */
    function resolvePlatformFromUrl(rawUrl) {
        if (!rawUrl) return { slug: '', prettyName: null, displayValue: '', isDbMatch: false };
        try {
            const url = new URL(rawUrl);
            if (url.protocol.startsWith('chrome') || url.protocol.startsWith('edge') || url.protocol.startsWith('about') || url.protocol.startsWith('moz')) {
                return { slug: '', prettyName: null, displayValue: '', isDbMatch: false };
            }
            const hostname = url.hostname;
            const slug = (typeof FrankPassUtils !== 'undefined')
                ? FrankPassUtils.getNormalizedPlatform(hostname)
                : hostname.replace(/^www\./, '').split('.')[0];

            const prettyName = (typeof FrankPassUtils !== 'undefined' && window.regionalPlatforms)
                ? FrankPassUtils.getPrettyNameFromDB(slug, window.regionalPlatforms)
                : null;

            return {
                slug,
                prettyName,
                displayValue: prettyName || slug,
                isDbMatch: !!prettyName
            };
        } catch (e) {
            return { slug: '', prettyName: null, displayValue: '', isDbMatch: false };
        }
    }

    /** Populate & filter datalist options */
    function populatePlatformDatalist(filterQuery = '') {
        const list = document.getElementById('platform-list');
        if (!list || !window.regionalPlatforms) return;

        if (currentPlatformCache.length === 0) {
            const seen = new Set();
            const keys = ['Global', 'in', 'us', 'gb', 'ca', 'au', 'de', 'fr'];
            keys.forEach(k => {
                (window.regionalPlatforms[k] || []).forEach(p => {
                    if (!seen.has(p)) {
                        seen.add(p);
                        currentPlatformCache.push(p);
                    }
                });
            });
        }

        list.innerHTML = '';
        const q = (filterQuery || '').toLowerCase().trim();
        const matched = q
            ? currentPlatformCache.filter(p => p.toLowerCase().includes(q)).slice(0, 30)
            : currentPlatformCache.slice(0, 30);

        const fragment = document.createDocumentFragment();
        matched.forEach(p => {
            const opt = document.createElement('option');
            opt.value = p;
            fragment.appendChild(opt);
        });
        list.appendChild(fragment);
    }

    // ==================== LICENSE VALIDATION HELPER ====================
    async function validateLicenseKey(key) {
        const rawKey = key.trim();
        const deviceId = await getOrCreateDeviceId();

        // 1. Try real Cloudflare API validation if online
        try {
            const resp = await fetch('https://frankpass.com/api/validate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key: rawKey, deviceId })
            });

            if (resp.ok) {
                const res = await resp.json();
                if (res && res.valid) {
                    return {
                        tier: res.tier,
                        label: res.label || TIER_LABELS[res.tier] || res.tier.toUpperCase()
                    };
                }
            }
        } catch (e) {
            console.warn('API validation offline/fallback:', e);
        }

        // 2. Offline Cryptographic Device-Locked Signature Validation
        // Format: FRANK-<TIER_CODE>-<DEV1>-<DEV2>-<DEV3>-<CHECKSUM>
        const parts = rawKey.toUpperCase().split('-');
        if (parts.length === 6 && parts[0] === 'FRANK') {
            const tierCode = parts[1]; // S, G, P, D
            const tokenDevId = `FP-${parts[2]}-${parts[3]}-${parts[4]}`;
            const sig = parts[5];

            if (tokenDevId !== deviceId) {
                return {
                    error: `Device Mismatch: This key is locked to device ${tokenDevId}, but your device is ${deviceId}.`
                };
            }

            const dataToSign = `${tokenDevId}|${tierCode}|${MASTER_OFFLINE_SALT}`;
            const hash = await sha256(dataToSign);
            const expectedSig = hash.substring(0, 8).toUpperCase();

            if (sig === expectedSig) {
                const tierMap = { 'S': 'silver', 'G': 'gold', 'P': 'platinum', 'D': 'diamond' };
                const tier = tierMap[tierCode] || 'gold';
                return {
                    tier: tier,
                    label: TIER_LABELS[tier] || tier.toUpperCase()
                };
            } else {
                return { error: 'Invalid license signature checksum.' };
            }
        }

        // 3. Local fallback for testing & offline mode
        if (rawKey === 'TEST-TRIAL' || rawKey.startsWith('FRANK-TRIAL-')) return { tier: 'diamond', label: '💎 DIAMOND (Trial)' };
        if (rawKey === 'TEST-GOLD' || rawKey.startsWith('FRANK-G-')) return { tier: 'gold', label: '🥇 GOLD' };
        if (rawKey === 'TEST-PLATINUM' || rawKey.startsWith('FRANK-P-')) return { tier: 'platinum', label: '🏆 PLATINUM' };
        if (rawKey === 'TEST-DIAMOND' || rawKey.startsWith('FRANK-D-')) return { tier: 'diamond', label: '💎 DIAMOND' };
        if (rawKey === 'TEST-SILVER' || rawKey.startsWith('FRANK-S-')) return { tier: 'silver', label: '🥈 SILVER' };
        return null;
    }

    // ==================== INIT ====================
    async function init() {
        const data = await getData(['fp_profiles', 'fp_license']);
        profiles = data.fp_profiles || [];
        license = data.fp_license || { key: '', tier: 'none', maxProfiles: 0 };

        // Ensure Device ID is generated and shown
        const devId = await getOrCreateDeviceId();
        const actDevEl = document.getElementById('activation-device-id');
        if (actDevEl) actDevEl.textContent = devId;
        const modalDevEl = document.getElementById('modal-device-id');
        if (modalDevEl) modalDevEl.textContent = devId;

        // Populate initial datalist cache
        populatePlatformDatalist();

        // If no valid license and no profiles exist yet, show activation/welcome screen
        if (!license.key || license.tier === 'none') {
            updateBadge();
            document.getElementById('header-upgrade-btn').classList.remove('hidden');
            showScreen(screenActivation);
            return;
        }

        updateBadge();
        renderProfileList();
        showScreen(screenProfiles);
    }

    function updateBadge() {
        const badge = document.getElementById('license-badge');
        if (!license || license.tier === 'none') {
            badge.textContent = 'FREE';
            badge.className = 'badge-free';
            return;
        }
        badge.textContent = TIER_LABELS[license.tier] || 'PRO';
        badge.className = `badge-${license.tier || 'silver'}`;
    }

    // ==================== PROFILE LIST ====================
    function renderProfileList() {
        const list = document.getElementById('profile-list');
        const addBtn = document.getElementById('add-profile-btn');
        const limitMsg = document.getElementById('profile-limit-msg');
        const limitContainer = document.getElementById('profile-limit-container');
        const tierBadge = document.getElementById('tier-counter-badge');
        list.innerHTML = '';

        const maxAllowed = TIER_LIMITS[license.tier] || 1;
        const currentTierLabel = TIER_LABELS[license.tier] || (license.tier === 'none' ? 'FREE' : 'PRO');

        if (tierBadge) {
            const maxStr = maxAllowed === Infinity ? '∞' : maxAllowed;
            tierBadge.textContent = `${currentTierLabel}: ${profiles.length}/${maxStr}`;
        }

        if (profiles.length === 0) {
            list.innerHTML = '<p style="text-align:center;color:#888;font-size:0.82rem;margin:14px 0;line-height:1.4;">No profiles yet.<br>Create a profile to save your Master Key with 4-Digit PIN protection.</p>';
        }

        profiles.forEach(p => {
            const card = document.createElement('div');
            card.className = 'profile-card';
            const initials = p.name.substring(0, 2).toUpperCase();
            card.innerHTML = `
                <div class="profile-avatar" style="background:${p.color || '#6c5ce7'};">${initials}</div>
                <span class="profile-card-name">${p.name}</span>
                <button class="delete-profile-btn" data-id="${p.id}" title="Delete profile">✕</button>
                <span class="profile-card-arrow">›</span>
            `;
            card.addEventListener('click', (e) => {
                if (e.target.classList.contains('delete-profile-btn')) return;
                openPinScreen(p.id, 'unlock_profile');
            });
            list.appendChild(card);
        });

        // Delete profile handlers
        list.querySelectorAll('.delete-profile-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                openPinScreen(btn.dataset.id, 'delete_profile');
            });
        });

        // Show/hide add button based on limit
        if (profiles.length >= maxAllowed && license.tier !== 'diamond') {
            addBtn.classList.add('hidden');
            if (limitContainer) limitContainer.classList.remove('hidden');
            if (limitMsg) limitMsg.textContent = `Profile limit reached for ${currentTierLabel} (${profiles.length}/${maxAllowed}).`;
        } else {
            addBtn.classList.remove('hidden');
            if (limitContainer) limitContainer.classList.add('hidden');
        }
    }

    // Add Profile button
    document.getElementById('add-profile-btn').addEventListener('click', () => {
        if (!license || license.tier === 'none') {
            openUpgradeModal();
            return;
        }
        openSetupWizard();
    });

    // Profile Limit Upgrade button
    const limitUpBtn = document.getElementById('profile-limit-upgrade-btn');
    if (limitUpBtn) {
        limitUpBtn.addEventListener('click', () => {
            openUpgradeModal();
        });
    }

    // ===== GUEST MODE BUTTONS =====
    document.getElementById('guest-mode-btn').addEventListener('click', () => {
        openGuestMode();
    });

    const actGuestBtn = document.getElementById('activation-guest-btn');
    if (actGuestBtn) {
        actGuestBtn.addEventListener('click', () => {
            openGuestMode();
        });
    }

    function openGuestMode() {
        activeProfileId = null; // Guest = no profile
        const secretEl = document.getElementById('secret');
        secretEl.value = '';
        secretEl.type = 'password';
        secretEl.readOnly = false;
        secretEl.classList.add('secret-editable');
        secretEl.placeholder = 'Type your master phrase here...';

        document.getElementById('gen-profile-name').textContent = `👤 Guest (Temporary)`;
        document.getElementById('secret-status-hint').textContent = `✏️ Type your Secret Key. Nothing is saved.`;
        document.getElementById('guest-save-group').classList.remove('hidden');
        document.getElementById('guest-save-secret').checked = false;
        document.getElementById('toggle-secret').textContent = '👁️';
        document.getElementById('username').value = '';
        document.getElementById('platform').value = '';
        document.getElementById('output').classList.add('hidden');

        // Populate datalist
        populatePlatformDatalist();

        // Auto-detect platform for guest with Database pretty-name matching & fallback
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].url) {
                const res = resolvePlatformFromUrl(tabs[0].url);
                if (res.displayValue) {
                    const platInp = document.getElementById('platform');
                    platInp.value = res.displayValue;
                    
                    const hintEl = document.getElementById('platform-hint');
                    if (hintEl && typeof FrankPassUtils !== 'undefined') {
                        hintEl.textContent = FrankPassUtils.getSeedHint(res.displayValue);
                    }
                    
                    const validIcon = document.getElementById('platform-valid-icon');
                    if (validIcon) validIcon.classList.toggle('hidden', !res.isDbMatch);
                    populatePlatformDatalist(res.displayValue);
                }

                // Fetch username/email automatically for Guest Mode
                chrome.tabs.sendMessage(tabs[0].id, { type: 'FETCH_USERNAME' }, (res) => {
                    if (!chrome.runtime.lastError && res && res.username) {
                        document.getElementById('username').value = res.username;
                    } else {
                        document.getElementById('username').value = '';
                    }
                });
            }
        });

        if (license && license.tier !== 'diamond') {
            document.getElementById('header-upgrade-btn').classList.remove('hidden');
        }
        showScreen(screenGenerator);
    }

    // ==================== PIN LOCK SCREEN ====================
    function openPinScreen(profileId, context) {
        activeProfileId = profileId;
        pinContext = context;
        const profile = profiles.find(p => p.id === profileId);
        if (!profile) return;

        const pinHintEl = document.querySelector('.pin-hint');
        if (context === 'unlock_profile') {
            document.getElementById('pin-username').textContent = `Unlock ${profile.name}`;
            if (pinHintEl) pinHintEl.textContent = 'Enter your 4-digit PIN to access profile';
        } else if (context === 'delete_profile') {
            document.getElementById('pin-username').textContent = `Delete ${profile.name}`;
            if (pinHintEl) pinHintEl.textContent = 'Enter PIN to confirm deletion';
        } else if (context === 'view_secret') {
            document.getElementById('pin-username').textContent = `Reveal Master Key`;
            if (pinHintEl) pinHintEl.textContent = 'Enter PIN to view plain secret';
        }
        const pinAvatar = document.getElementById('pin-avatar');
        pinAvatar.textContent = profile.name.substring(0, 2).toUpperCase();
        pinAvatar.style.backgroundColor = profile.color || '#6c5ce7';
        pinBuffer = '';
        pinAttempts = 0;
        updatePinDots();
        document.getElementById('pin-error').classList.add('hidden');
        showScreen(screenPin);
    }

    function updatePinDots() {
        const dots = document.querySelectorAll('#pin-dots .pin-dot');
        dots.forEach((dot, i) => {
            dot.classList.toggle('filled', i < pinBuffer.length);
            dot.classList.remove('error');
        });
    }

    function flashPinError() {
        const dots = document.querySelectorAll('#pin-dots .pin-dot');
        dots.forEach(d => { d.classList.add('error'); d.classList.remove('filled'); });
        document.getElementById('pin-error').classList.remove('hidden');
        setTimeout(() => {
            dots.forEach(d => d.classList.remove('error'));
            pinBuffer = '';
            updatePinDots();
        }, 600);
    }

    // PIN Pad keys (Mouse clicks)
    document.querySelectorAll('.pin-key[data-val]').forEach(key => {
        key.addEventListener('click', async () => handlePinInput(key.dataset.val));
    });

    // Backspace (Mouse click)
    document.getElementById('pin-backspace').addEventListener('click', handlePinBackspace);

    // Keyboard support for PIN pad
    document.addEventListener('keydown', async (e) => {
        if (!document.getElementById('screen-pin').classList.contains('hidden')) {
            if (Date.now() < pinLockoutUntil) return;

            // Numbers 0-9
            if (/^[0-9]$/.test(e.key)) {
                await handlePinInput(e.key);
            } 
            // Alphabet check (shows specific error)
            else if (/^[a-zA-Z]$/.test(e.key)) {
                const err = document.getElementById('pin-error');
                err.textContent = 'Please use numbers (0-9) only.';
                err.classList.remove('hidden');
                setTimeout(() => err.classList.add('hidden'), 2000);
            }
            // Backspace
            else if (e.key === 'Backspace') {
                handlePinBackspace();
            }
        }
    });

    async function handlePinInput(val) {
        if (pinBuffer.length >= 4) return;
        if (Date.now() < pinLockoutUntil) return;
        
        pinBuffer += val;
        updatePinDots();
        if (pinBuffer.length === 4) {
            await verifyPin(pinBuffer);
        }
    }

    function handlePinBackspace() {
        if (pinBuffer.length > 0) {
            pinBuffer = pinBuffer.slice(0, -1);
            updatePinDots();
            document.getElementById('pin-error').classList.add('hidden');
        }
    }

    async function verifyPin(enteredPin) {
        const profile = profiles.find(p => p.id === activeProfileId);
        if (!profile) return;

        const hash = await sha256(enteredPin);
        if (hash === profile.pinHash) {
            // Success! 
            if (pinContext === 'unlock_profile') {
                const pData = profiles.find(x => x.id === activeProfileId);
                openGenerator(pData);
            } else if (pinContext === 'delete_profile') {
                profiles = profiles.filter(x => x.id !== profile.id);
                await setData({ fp_profiles: profiles });
                renderProfileList();
                showScreen(screenProfiles);
            } else if (pinContext === 'view_secret') {
                // Show the secret
                const inp = document.getElementById('secret');
                inp.value = profile.secretKey;
                inp.type = 'text';
                document.getElementById('toggle-secret').textContent = '🙈';
                showScreen(screenGenerator);
            }
        } else {
            pinAttempts++;
            if (pinAttempts >= 3) {
                pinLockoutUntil = Date.now() + 30000;
                startPinLockoutTimer();
            } else {
                document.getElementById('pin-error').textContent = `Wrong PIN. ${3 - pinAttempts} attempt(s) left.`;
                flashPinError();
            }
        }
    }

    let lockoutInterval;
    function startPinLockoutTimer() {
        clearInterval(lockoutInterval);
        const errEl = document.getElementById('pin-error');
        errEl.classList.remove('hidden');
        
        const updateTimer = () => {
            const timeLeft = Math.ceil((pinLockoutUntil - Date.now()) / 1000);
            if (timeLeft <= 0) {
                clearInterval(lockoutInterval);
                errEl.classList.add('hidden');
                pinAttempts = 0;
            } else {
                errEl.textContent = `Locked. Try again in ${timeLeft}s`;
            }
        };
        updateTimer();
        lockoutInterval = setInterval(updateTimer, 1000);
        
        // Immediately flash error and clear buffer
        const dots = document.querySelectorAll('#pin-dots .pin-dot');
        dots.forEach(d => { d.classList.add('error'); d.classList.remove('filled'); });
        setTimeout(() => {
            dots.forEach(d => d.classList.remove('error'));
            pinBuffer = '';
            updatePinDots();
        }, 600);
    }

    // Back from PIN
    document.getElementById('pin-back-btn').addEventListener('click', () => {
        if (pinContext === 'view_secret') {
            showScreen(screenGenerator);
        } else {
            showScreen(screenProfiles);
        }
    });

    // ==================== FORGOT PIN / RECOVERY ====================
    document.getElementById('forgot-pin-btn').addEventListener('click', () => {
        openRecoveryScreen();
    });

    function openRecoveryScreen() {
        const profile = profiles.find(p => p.id === activeProfileId);
        if (!profile) return;

        const container = document.getElementById('recovery-questions-container');
        container.innerHTML = '';

        document.getElementById('recovery-hint').textContent =
            `Answer at least ${profile.minCorrect} of ${profile.questions.length} questions correctly.`;

        profile.questions.forEach(q => {
            const sqDef = SECURITY_QUESTIONS.find(s => s.id === q.qId);
            if (!sqDef) return;
            const group = document.createElement('div');
            group.className = 'recovery-q-group';
            group.innerHTML = `
                <label>${sqDef.text}</label>
                <input type="text" class="recovery-answer" data-qid="${q.qId}" placeholder="Your answer" autocomplete="off">
            `;
            container.appendChild(group);
        });

        document.getElementById('recovery-error').classList.add('hidden');
        showScreen(screenRecovery);
    }

    // Recovery Submit
    document.getElementById('recovery-submit-btn').addEventListener('click', async () => {
        const profile = profiles.find(p => p.id === activeProfileId);
        if (!profile) return;

        const inputs = document.querySelectorAll('.recovery-answer');
        let correctCount = 0;

        for (const input of inputs) {
            const qId = parseInt(input.dataset.qid);
            const answer = normalizeAnswer(input.value);
            if (!answer) continue;
            const hash = await sha256(answer);
            const stored = profile.questions.find(q => q.qId === qId);
            if (stored && stored.ansHash === hash) {
                correctCount++;
            }
        }

        if (correctCount >= profile.minCorrect) {
            // Verified! Show new PIN screen
            showScreen(screenNewPin);
            document.getElementById('new-pin-error').classList.add('hidden');
            document.getElementById('new-pin').value = '';
            document.getElementById('new-pin-confirm').value = '';
        } else {
            const errEl = document.getElementById('recovery-error');
            errEl.textContent = `Only ${correctCount} correct. You need at least ${profile.minCorrect}.`;
            errEl.classList.remove('hidden');
        }
    });

    // Recovery Back
    document.getElementById('recovery-back-btn').addEventListener('click', () => {
        showScreen(screenPin);
    });

    // ==================== NEW PIN (After Recovery) ====================
    const newPinInp = document.getElementById('new-pin');
    const newPinConfInp = document.getElementById('new-pin-confirm');
    [newPinInp, newPinConfInp].forEach(el => {
        if (el) {
            el.oninput = (e) => {
                if (/[^0-9]/.test(e.target.value)) {
                    e.target.value = e.target.value.replace(/[^0-9]/g, '');
                }
            };
        }
    });

    document.getElementById('new-pin-save-btn').addEventListener('click', async () => {
        const pin = document.getElementById('new-pin').value;
        const confirm = document.getElementById('new-pin-confirm').value;
        const errEl = document.getElementById('new-pin-error');

        if (!/^\d{4}$/.test(pin)) {
            errEl.textContent = 'PIN must be exactly 4 digits.';
            errEl.classList.remove('hidden');
            return;
        }
        if (pin !== confirm) {
            errEl.textContent = 'PINs do not match.';
            errEl.classList.remove('hidden');
            return;
        }

        const profile = profiles.find(p => p.id === activeProfileId);
        if (!profile) return;

        try {
            // Re-encrypt with new PIN isn't needed anymore, just save the new PIN hash
            const newPinHash = await sha256(pin);
            profile.pinHash = newPinHash;

            await setData({ fp_profiles: profiles });

            // Go to profile list since context might be lost, or just go to generator
            openGenerator(profile);
        } catch (e) {
            errEl.textContent = 'Error resetting PIN. Please try again.';
            errEl.classList.remove('hidden');
            console.error(e);
        }
    });

    // ==================== SETUP WIZARD ====================
    function openSetupWizard(prefillSecret = '') {
        document.getElementById('setup-name').value = '';
        const pinInp = document.getElementById('setup-pin');
        const pinConfInp = document.getElementById('setup-pin-confirm');
        
        pinInp.value = '';
        pinConfInp.value = '';
        
        // Ensure numeric only for PIN fields during setup
        [pinInp, pinConfInp].forEach(el => {
            el.oninput = (e) => {
                const val = e.target.value;
                if (/[^0-9]/.test(val)) {
                    e.target.value = val.replace(/[^0-9]/g, '');
                    const err = document.getElementById('setup-step1-error');
                    err.textContent = 'Please use numbers (0-9) only.';
                    err.classList.remove('hidden');
                    setTimeout(() => err.classList.add('hidden'), 2000);
                }
            };
        });

        document.getElementById('setup-secret').value = prefillSecret;
        document.getElementById('setup-step1-error').classList.add('hidden');
        document.getElementById('setup-step2-error').classList.add('hidden');
        document.getElementById('setup-step3-error').classList.add('hidden');

        // Reset color picker
        setupSelectedColor = '#6c5ce7';
        document.querySelectorAll('.color-swatch').forEach(s => {
            s.classList.remove('active');
            if (s.dataset.color === '#6c5ce7') s.classList.add('active');
        });

        // Reset wizard to Step 1
        document.getElementById('setup-step-1').classList.remove('hidden');
        document.getElementById('setup-step-2').classList.add('hidden');
        document.getElementById('setup-step-3').classList.add('hidden');

        // Populate Security Questions
        renderSetupQuestions();

        showScreen(screenSetup);
    }

    function renderSetupQuestions() {
        const container = document.getElementById('setup-questions-container');
        if (!container) return;
        container.innerHTML = '';

        SECURITY_QUESTIONS.forEach((q, idx) => {
            const item = document.createElement('div');
            item.className = 'sq-item';
            item.dataset.qid = q.id;

            // Auto-check top 3 questions for easy 1-click UX
            const isAutoChecked = idx < 3;
            if (isAutoChecked) item.classList.add('active');

            item.innerHTML = `
                <div class="sq-check-row">
                    <input type="checkbox" id="sq-${q.id}" data-qid="${q.id}" ${isAutoChecked ? 'checked' : ''}>
                    <label class="sq-label" for="sq-${q.id}">${q.text}</label>
                </div>
                <div class="sq-answer ${isAutoChecked ? '' : 'hidden'}">
                    <input type="text" class="sq-ans-input" data-qid="${q.id}" placeholder="Type your answer here..." autocomplete="off">
                </div>
            `;
            container.appendChild(item);
        });

        // Toggle answer field on checkbox change
        container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', () => {
                const item = cb.closest('.sq-item');
                const ansDiv = item.querySelector('.sq-answer');
                if (cb.checked) {
                    item.classList.add('active');
                    ansDiv.classList.remove('hidden');
                    ansDiv.querySelector('input').focus();
                } else {
                    item.classList.remove('active');
                    ansDiv.classList.add('hidden');
                    ansDiv.querySelector('input').value = '';
                }
                updateMinCorrectOptions();
            });
        });

        updateMinCorrectOptions();
    }

    function updateMinCorrectOptions() {
        const checked = document.querySelectorAll('#setup-questions-container input[type="checkbox"]:checked').length;
        const select = document.getElementById('setup-min-correct');
        if (!select) return;
        select.innerHTML = '';
        const maxOpt = Math.max(checked, 2);
        for (let i = 2; i <= maxOpt; i++) {
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = i;
            if (i === Math.min(2, checked)) opt.selected = true;
            select.appendChild(opt);
        }
    }

    // Setup Toggle Secret
    document.getElementById('setup-toggle-secret').addEventListener('click', (e) => {
        e.preventDefault();
        const inp = document.getElementById('setup-secret');
        const btn = document.getElementById('setup-toggle-secret');
        if (inp.type === 'password') { inp.type = 'text'; btn.textContent = '🙈'; }
        else { inp.type = 'password'; btn.textContent = '👁️'; }
    });

    // Step 1 ← Cancel
    document.getElementById('setup-prev-1').addEventListener('click', () => {
        const guestCheck = document.getElementById('guest-save-secret');
        if (guestCheck) guestCheck.checked = false;
        if (license && license.tier !== 'none') {
            renderProfileList();
            showScreen(screenProfiles);
        } else {
            openGuestMode();
        }
    });

    // Step 1 → Step 2
    document.getElementById('setup-next-1').addEventListener('click', () => {
        const name = document.getElementById('setup-name').value.trim();
        const pin = document.getElementById('setup-pin').value;
        const pinC = document.getElementById('setup-pin-confirm').value;
        const err = document.getElementById('setup-step1-error');

        if (!name) { err.textContent = 'Please enter a display name.'; err.classList.remove('hidden'); return; }
        if (!/^\d{4}$/.test(pin)) { err.textContent = 'PIN must be exactly 4 digits.'; err.classList.remove('hidden'); return; }
        if (pin !== pinC) { err.textContent = 'PINs do not match.'; err.classList.remove('hidden'); return; }

        err.classList.add('hidden');
        document.getElementById('setup-step-1').classList.add('hidden');
        document.getElementById('setup-step-2').classList.remove('hidden');
    });

    // Step 2 → Step 3
    document.getElementById('setup-next-2').addEventListener('click', () => {
        const secret = document.getElementById('setup-secret').value.trim();
        const err = document.getElementById('setup-step2-error');
        if (!secret) { err.textContent = 'Please enter your Secret Master Key.'; err.classList.remove('hidden'); return; }
        err.classList.add('hidden');
        document.getElementById('setup-step-2').classList.add('hidden');
        document.getElementById('setup-step-3').classList.remove('hidden');
    });

    // Step 2 ← back
    document.getElementById('setup-prev-2').addEventListener('click', () => {
        document.getElementById('setup-step-2').classList.add('hidden');
        document.getElementById('setup-step-1').classList.remove('hidden');
    });

    // Step 3 ← back
    document.getElementById('setup-prev-3').addEventListener('click', () => {
        document.getElementById('setup-step-3').classList.add('hidden');
        document.getElementById('setup-step-2').classList.remove('hidden');
    });

    // Finish - Create Profile
    document.getElementById('setup-finish').addEventListener('click', async () => {
        const err = document.getElementById('setup-step3-error');
        const checkedBoxes = document.querySelectorAll('#setup-questions-container input[type="checkbox"]:checked');

        if (checkedBoxes.length < 3) {
            err.textContent = 'Please select at least 3 security questions.';
            err.classList.remove('hidden');
            return;
        }

        // Validate all selected questions have answers
        const questions = [];
        for (const cb of checkedBoxes) {
            const qId = parseInt(cb.dataset.qid);
            const ansInput = document.querySelector(`.sq-ans-input[data-qid="${qId}"]`);
            const ans = normalizeAnswer(ansInput.value);
            if (!ans) {
                err.textContent = 'Please answer all selected questions.';
                err.classList.remove('hidden');
                return;
            }
            questions.push({ qId, ansHash: await sha256(ans) });
        }

        const minCorrect = parseInt(document.getElementById('setup-min-correct').value);
        const name = document.getElementById('setup-name').value.trim();
        const pin = document.getElementById('setup-pin').value;
        const secret = document.getElementById('setup-secret').value.trim();

        const profileId = uuid();
        const pinHash = await sha256(pin);

        const newProfile = {
            id: profileId,
            name,
            pinHash,
            secretKey: secret, // stored securely in extension's local DB, accessible without PIN for quick generation
            questions,
            minCorrect,
            color: setupSelectedColor,
            createdAt: new Date().toISOString()
        };

        profiles.push(newProfile);
        await setData({ fp_profiles: profiles });

        err.classList.add('hidden');

        // Open generator directly
        openGenerator(newProfile);
    });

    // ==================== GENERATOR SCREEN ====================
    function openGenerator(profile) {
        activeProfileId = profile.id;
        document.getElementById('gen-profile-name').textContent = profile.name;
        document.getElementById('gen-avatar-circle').style.backgroundColor = profile.color || '#6c5ce7';

        const secretEl = document.getElementById('secret');
        secretEl.value = profile.secretKey;
        secretEl.type = 'password';
        secretEl.readOnly = true;
        secretEl.classList.remove('secret-editable');
        secretEl.placeholder = 'Your master phrase';
        document.getElementById('toggle-secret').textContent = '👁️';
        document.getElementById('secret-status-hint').textContent = '🔒 Loaded from your profile. Protected by PIN.';
        document.getElementById('guest-save-group').classList.add('hidden');
        document.getElementById('username').value = '';
        document.getElementById('output').classList.add('hidden');

        // Populate datalist
        populatePlatformDatalist();

        // Auto-detect platform with Database pretty-name matching & fallback
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].url) {
                const res = resolvePlatformFromUrl(tabs[0].url);
                if (res.displayValue) {
                    const platInp = document.getElementById('platform');
                    platInp.value = res.displayValue;
                    
                    const hintEl = document.getElementById('platform-hint');
                    if (hintEl && typeof FrankPassUtils !== 'undefined') {
                        hintEl.textContent = FrankPassUtils.getSeedHint(res.displayValue);
                    }
                    
                    const validIcon = document.getElementById('platform-valid-icon');
                    if (validIcon) validIcon.classList.toggle('hidden', !res.isDbMatch);
                    populatePlatformDatalist(res.displayValue);
                }

                // Fetch username/email automatically if available
                chrome.tabs.sendMessage(tabs[0].id, { type: 'FETCH_USERNAME' }, (res) => {
                    if (!chrome.runtime.lastError && res && res.username) {
                        document.getElementById('username').value = res.username;
                    } else {
                        document.getElementById('username').value = '';
                    }
                });
            }
        });

        // Show/hide upgrade button in header based on tier
        if (license && license.tier !== 'diamond') {
            document.getElementById('header-upgrade-btn').classList.remove('hidden');
        } else {
            document.getElementById('header-upgrade-btn').classList.add('hidden');
        }

        showScreen(screenGenerator);
    }

    // Platform input live autocomplete, seed hint and validation checkmark
    const platformInput = document.getElementById('platform');
    const platformHint = document.getElementById('platform-hint');
    const platformValid = document.getElementById('platform-valid-icon');

    if (platformInput) {
        platformInput.addEventListener('input', (e) => {
            const raw = e.target.value.trim();
            populatePlatformDatalist(raw);

            if (typeof FrankPassUtils === 'undefined') return;
            const hint = raw ? FrankPassUtils.getSeedHint(raw) : '';
            if (platformHint) platformHint.textContent = hint;

            const normalized = FrankPassUtils.getNormalizedPlatform(raw);
            const inDB = FrankPassUtils.getPrettyNameFromDB(normalized, window.regionalPlatforms);
            if (platformValid) platformValid.classList.toggle('hidden', !inDB);
        });
    }

    // Copy Device ID Button Handlers
    const copyDevBtn = document.getElementById('copy-device-id-btn');
    if (copyDevBtn) {
        copyDevBtn.addEventListener('click', async () => {
            const devId = await getOrCreateDeviceId();
            navigator.clipboard.writeText(devId).then(() => {
                copyDevBtn.textContent = '✅ Copied!';
                setTimeout(() => copyDevBtn.textContent = '📋 Copy', 2000);
            });
        });
    }

    const modalCopyDevBtn = document.getElementById('modal-copy-dev-btn');
    if (modalCopyDevBtn) {
        modalCopyDevBtn.addEventListener('click', async () => {
            const devId = await getOrCreateDeviceId();
            navigator.clipboard.writeText(devId).then(() => {
                modalCopyDevBtn.textContent = '✅';
                setTimeout(() => modalCopyDevBtn.textContent = '📋', 2000);
            });
        });
    }

    // Toggle secret visibility - free in guest mode, PIN-protected in profile mode
    document.getElementById('toggle-secret').addEventListener('click', (e) => {
        e.preventDefault();
        const inp = document.getElementById('secret');
        if (activeProfileId === null) {
            // Guest mode - toggle freely
            if (inp.type === 'password') { inp.type = 'text'; document.getElementById('toggle-secret').textContent = '🙈'; }
            else { inp.type = 'password'; document.getElementById('toggle-secret').textContent = '👁️'; }
        } else {
            // Profile mode - require PIN to reveal
            if (inp.type === 'password') { 
                openPinScreen(activeProfileId, 'view_secret');
            } else { 
                inp.type = 'password'; 
                document.getElementById('toggle-secret').textContent = '👁️'; 
            }
        }
    });

    // 'Save Secret Key Locally' checkbox in Guest mode - launches Setup Wizard
    document.getElementById('guest-save-secret').addEventListener('change', (e) => {
        if (e.target.checked) {
            const currentSecret = document.getElementById('secret').value.trim();
            openSetupWizard(currentSecret);
        }
    });

    // Switch profile
    document.getElementById('gen-switch-profile').addEventListener('click', () => {
        // Clear sensitive data
        document.getElementById('secret').value = '';
        document.getElementById('platform').value = '';
        document.getElementById('output').classList.add('hidden');
        showScreen(screenProfiles);
        renderProfileList();
    });

    // Generate & Autofill
    document.getElementById('generate-btn').addEventListener('click', async () => {
        const rawPlatform = document.getElementById('platform').value.trim();
        const platform = (typeof FrankPassUtils !== 'undefined')
            ? FrankPassUtils.getNormalizedPlatform(rawPlatform)
            : rawPlatform.toLowerCase().replace(/[^a-z0-9]/g, '');

        const username = document.getElementById('username').value.trim().toLowerCase();
        const secret = document.getElementById('secret').value.toLowerCase().replace(/\s+/g, '');
        const variant = parseInt(document.getElementById('variant').value, 10) || 1;
        const profileType = document.getElementById('profile-type').value;
        const length = parseInt(document.getElementById('length').value, 10) || 16;

        if (!platform || !secret) {
            alert('Platform and Secret Key are required.');
            return;
        }

        try {
            const password = await FRANKPASS_CORE.generate(platform, username, secret, variant, profileType, length, null);
            document.getElementById('generated-pwd').value = password;
            document.getElementById('generated-pwd').type = 'password';
            document.getElementById('toggle-generated-btn').textContent = '👁️';
            document.getElementById('output').classList.remove('hidden');

            const isAutoClear = document.getElementById('auto-clear').checked;
            const genBtn = document.getElementById('generate-btn');

            // Copy to clipboard immediately
            navigator.clipboard.writeText(password).then(() => {
                if (isAutoClear) {
                    setTimeout(() => {
                        navigator.clipboard.writeText('').catch(()=>{});
                    }, 30000); // clear after 30 seconds
                }
            });

            // Dual Autofill Strategy: Message + Scripting Fallback
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (!tabs[0] || !tabs[0].id) {
                    genBtn.textContent = '📋 Copied to Clipboard!';
                    setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                    return;
                }

                const tabId = tabs[0].id;
                const tabUrl = tabs[0].url || '';

                if (tabUrl.startsWith('chrome://') || tabUrl.startsWith('edge://') || tabUrl.startsWith('about:') || tabUrl.startsWith('chrome-extension://')) {
                    genBtn.textContent = '📋 Copied to Clipboard!';
                    setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                    return;
                }

                chrome.tabs.sendMessage(tabId, { type: 'AUTOFILL', password }, (res) => {
                    if (!chrome.runtime.lastError && res && res.status === 'success') {
                        genBtn.textContent = '✅ Autofilled & Copied!';
                        setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                    } else {
                        // Fallback: If content script was not injected yet (pre-existing tab), inject directly via chrome.scripting
                        if (chrome.scripting && chrome.scripting.executeScript) {
                            chrome.scripting.executeScript({
                                target: { tabId },
                                func: (pwd) => {
                                    const allInputs = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"])'));
                                    let targets = allInputs.filter(el => el.type === 'password');
                                    if (targets.length === 0) {
                                        targets = allInputs.filter(el => {
                                            const n = (el.name || '').toLowerCase();
                                            const id = (el.id || '').toLowerCase();
                                            const ph = (el.placeholder || '').toLowerCase();
                                            return n.includes('pass') || id.includes('pass') || ph.includes('pass') || n.includes('pin') || id.includes('pin');
                                        });
                                    }
                                    if (targets.length > 0) {
                                        targets.forEach(t => {
                                            t.focus();
                                            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                                            if (setter) setter.call(t, pwd);
                                            else t.value = pwd;
                                            t.dispatchEvent(new Event('input', { bubbles: true }));
                                            t.dispatchEvent(new Event('change', { bubbles: true }));
                                            t.style.transition = 'all 0.3s ease';
                                            t.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.6)';
                                            t.style.borderColor = '#10b981';
                                            setTimeout(() => { t.style.boxShadow = ''; t.style.borderColor = ''; }, 1200);
                                        });
                                        return true;
                                    }
                                    return false;
                                },
                                args: [password]
                            }).then((results) => {
                                if (results && results[0] && results[0].result) {
                                    genBtn.textContent = '✅ Autofilled & Copied!';
                                } else {
                                    genBtn.textContent = '📋 Copied to Clipboard!';
                                }
                                setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                            }).catch(() => {
                                genBtn.textContent = '📋 Copied to Clipboard!';
                                setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                            });
                        } else {
                            genBtn.textContent = '📋 Copied to Clipboard!';
                            setTimeout(() => { genBtn.textContent = '⚡ Generate & Autofill'; }, 2000);
                        }
                    }
                });
            });

        } catch (e) {
            console.error(e);
            alert('Error generating password.');
        }
    });

    // Toggle Generated Password
    document.getElementById('toggle-generated-btn').addEventListener('click', () => {
        const input = document.getElementById('generated-pwd');
        const btn = document.getElementById('toggle-generated-btn');
        if (input.type === 'password') {
            input.type = 'text';
            btn.textContent = '🙈';
        } else {
            input.type = 'password';
            btn.textContent = '👁️';
        }
    });

    // Copy Generated Password
    document.getElementById('copy-btn').addEventListener('click', () => {
        const btn = document.getElementById('copy-btn');
        const pwd = document.getElementById('generated-pwd').value;
        const isAutoClear = document.getElementById('auto-clear').checked;
        
        navigator.clipboard.writeText(pwd).then(() => {
            btn.textContent = '✅ Copied!';
            setTimeout(() => btn.textContent = '📋 Copy', 2000);
            
            if (isAutoClear) {
                setTimeout(() => {
                    navigator.clipboard.writeText('').catch(()=>{});
                }, 30000);
            }
        });
    });

    // Length slider
    document.getElementById('length').addEventListener('input', (e) => {
        document.getElementById('len-val').textContent = e.target.value;
    });

    // ==================== ACTIVATION SCREEN (First-Time Gate) ====================
    document.getElementById('activation-activate-btn').addEventListener('click', async () => {
        const key = document.getElementById('activation-key-input').value.trim();
        const errEl = document.getElementById('activation-error');
        if (!key) { errEl.textContent = 'Please enter a license key.'; errEl.classList.remove('hidden'); return; }

        const btn = document.getElementById('activation-activate-btn');
        btn.disabled = true;
        btn.textContent = 'Validating...';

        try {
            const result = await validateLicenseKey(key);
            if (result) {
                license = {
                    key,
                    tier: result.tier,
                    maxProfiles: TIER_LIMITS[result.tier],
                    activatedAt: new Date().toISOString()
                };
                await setData({ fp_license: license });
                errEl.classList.add('hidden');
                updateBadge();
                renderProfileList();
                showScreen(screenProfiles);
                document.getElementById('header-upgrade-btn').classList.remove('hidden');
            } else {
                errEl.textContent = 'Invalid license key. Please check and try again.';
                errEl.classList.remove('hidden');
            }
        } catch (e) {
            errEl.textContent = 'Validation error. Please check your connection.';
            errEl.classList.remove('hidden');
        }
        btn.disabled = false;
        btn.textContent = '✓ Activate Key';
    });

    // Activation screen: Free Trial & Buy buttons → website
    document.getElementById('activation-trial-btn').addEventListener('click', () => {
        window.open('https://frankpass.com/pro.html', '_blank');
    });
    document.getElementById('activation-buy-btn').addEventListener('click', () => {
        window.open('https://frankpass.com/pro.html', '_blank');
    });

    // ==================== UPGRADE MODAL (Existing Users) ====================
    function openUpgradeModal() {
        const tierLabel = TIER_LABELS[license.tier] || 'SILVER';
        document.getElementById('modal-current-tier').textContent = tierLabel;
        document.getElementById('license-key-input').value = '';
        document.getElementById('modal-activation-error').classList.add('hidden');
        document.getElementById('license-modal').classList.remove('hidden');
    }

    document.getElementById('header-upgrade-btn').addEventListener('click', () => {
        openUpgradeModal();
    });

    document.getElementById('license-badge').addEventListener('click', () => {
        openUpgradeModal();
    });

    document.getElementById('cancel-modal-btn').addEventListener('click', () => {
        document.getElementById('license-modal').classList.add('hidden');
    });

    // Upgrade modal: "Get Key from Website" button
    document.getElementById('modal-website-btn').addEventListener('click', () => {
        window.open('https://frankpass.com/pro.html', '_blank');
    });

    // Upgrade modal: Activate new key
    document.getElementById('activate-modal-btn').addEventListener('click', async () => {
        const key = document.getElementById('license-key-input').value.trim();
        const errEl = document.getElementById('modal-activation-error');
        if (!key) { errEl.textContent = 'Please enter a license key.'; errEl.classList.remove('hidden'); return; }

        const btn = document.getElementById('activate-modal-btn');
        btn.disabled = true;
        btn.textContent = 'Validating...';

        try {
            const result = await validateLicenseKey(key);
            if (result) {
                license = {
                    key,
                    tier: result.tier,
                    maxProfiles: TIER_LIMITS[result.tier],
                    activatedAt: new Date().toISOString()
                };
                await setData({ fp_license: license });
                document.getElementById('license-modal').classList.add('hidden');
                updateBadge();
                renderProfileList();
                showScreen(screenProfiles);
                alert(`${result.label} Plan Activated! Enjoy FrankPass Pro.`);
            } else {
                errEl.textContent = 'Invalid license key. Please check and try again.';
                errEl.classList.remove('hidden');
            }
        } catch (e) {
            errEl.textContent = 'Validation error. Please check your connection.';
            errEl.classList.remove('hidden');
        }
        btn.disabled = false;
        btn.textContent = '✓ Activate New Key';
    });

    // ==================== START ====================
    init();
});

