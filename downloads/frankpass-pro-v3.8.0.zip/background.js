// Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
    console.log("FrankPass Extension Installed.");
});

// Used for handling shortcut commands if we want to run background scripts.
// Currently, _execute_action handles the Command+Shift+L shortcut natively by opening popup.html.
chrome.commands.onCommand.addListener((command) => {
    console.log("Command received:", command);
});
