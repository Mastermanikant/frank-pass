chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'FETCH_USERNAME') {
        const inputs = Array.from(document.querySelectorAll('input:not([type="password"]):not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"])'));
        
        let foundVal = '';
        for (const input of inputs) {
            const name = (input.name || '').toLowerCase();
            const id = (input.id || '').toLowerCase();
            const type = (input.type || '').toLowerCase();
            const placeholder = (input.placeholder || '').toLowerCase();
            const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase();
            
            const isMatch = type === 'email' || type === 'tel' ||
                ['user', 'email', 'login', 'phone', 'mobile', 'account', 'id', 'uname'].some(kw => 
                    name.includes(kw) || id.includes(kw) || placeholder.includes(kw) || ariaLabel.includes(kw)
                );

            if (isMatch) {
                if (input.value && input.value.trim().length > 0) {
                    foundVal = input.value.trim();
                    break;
                }
            }
        }
        sendResponse({ username: foundVal });
        return true;
    }

    if (request.type === 'AUTOFILL' && request.password) {
        const password = request.password;
        const allInputs = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"])'));
        
        // Priority 1: True password fields
        let targetFields = allInputs.filter(el => el.type === 'password');

        // Priority 2: Fallback to autocomplete / password name keywords
        if (targetFields.length === 0) {
            targetFields = allInputs.filter(el => {
                const ac = (el.getAttribute('autocomplete') || '').toLowerCase();
                const name = (el.name || '').toLowerCase();
                const id = (el.id || '').toLowerCase();
                const ph = (el.placeholder || '').toLowerCase();
                const aria = (el.getAttribute('aria-label') || '').toLowerCase();
                return ac.includes('password') || name.includes('pass') || id.includes('pass') || ph.includes('pass') || aria.includes('pass') || name.includes('pin') || id.includes('pin');
            });
        }

        // If focused element is one of them, prioritize it
        const activeEl = document.activeElement;
        if (activeEl && targetFields.includes(activeEl)) {
            targetFields = [activeEl, ...targetFields.filter(f => f !== activeEl)];
        }

        if (targetFields.length > 0) {
            let filledCount = 0;
            targetFields.forEach(targetField => {
                try {
                    targetField.focus();
                    
                    // Native setter support for React, Vue, Angular, Svelte
                    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                    if (nativeInputValueSetter) {
                        nativeInputValueSetter.call(targetField, password);
                    } else {
                        targetField.value = password;
                    }

                    // Dispatch events so framework state updates
                    targetField.dispatchEvent(new Event('input', { bubbles: true }));
                    targetField.dispatchEvent(new Event('change', { bubbles: true }));
                    targetField.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }));
                    targetField.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));
                    
                    // Visual green glow flash
                    const prevTransition = targetField.style.transition;
                    const prevShadow = targetField.style.boxShadow;
                    const prevBorder = targetField.style.borderColor;

                    targetField.style.transition = 'all 0.3s ease';
                    targetField.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.6)';
                    targetField.style.borderColor = '#10b981';

                    setTimeout(() => {
                        targetField.style.boxShadow = prevShadow;
                        targetField.style.borderColor = prevBorder;
                        targetField.style.transition = prevTransition;
                    }, 1200);

                    filledCount++;
                } catch (e) {
                    console.error("FrankPass autofill error:", e);
                }
            });

            sendResponse({ status: 'success', count: filledCount });
        } else {
            sendResponse({ status: 'not_found' });
        }
    }
    return true;
});
